animationDelay=100,minSearchTime=100,window.requestAnimationFrame((function(){new GameManager(4,KeyboardInputManager,HTMLActuator)}));
