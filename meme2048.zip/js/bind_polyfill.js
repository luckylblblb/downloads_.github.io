Function.prototype.bind=Function.prototype.bind||function(n){var t=this;return function(o){o instanceof Array||(o=[o]),t.apply(n,o)}};
